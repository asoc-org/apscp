## This file demonstrates the use of the SCAR-IAATO Peninsula SCP tool using tourism visitation scenarios (May 2025 version)

#NOTE: This file uses the visitor landing data (tvis). If you want to use the vessel landing data (tves), replace
#all instances of 'tvis' in this file with 'tves' (use 'ctrl + F) to find and replace


###########################################################################################
### STEP ONE - Install the necessary R packages

## Packages for running SCP, managing data frames, raster layers
install.packages(prioritizr, rgdal, dplyr, data.table, terra)

## Load in the packages
library(prioritizr)
library(rgdal)
library(dplyr)
library(data.table)
library(terra)

## If you would like to use the commercial exact-algorithm solver (Gurobi), it can be installed by following
#the instructions at: https://prioritizr.net/articles/gurobi_installation_guide.html
# Non-commercial, academic licences are available to researchers for free for one year.

## Load Gurobi (if using)
library(gurobi)

#NOTE: The gurobi solver is not necessary to run the SCP prioritsations in Prioritizr, other pre-installed solvers
#can be used although these are not as fast or powerful as Gurobi.



## A introduction to the use of the Prioritizr pacakage using examples is available online: 
# https://prioritizr.net/articles/prioritizr.html
# This tutorial can be followed if you would like background and context to the SCP process



###########################################################################################
### STEP TWO - Load in and prepare the data

## Set up your working directory (which is the document folder on your computer containing the downloaded input data)
setwd("C:/Users/XXUSERNAMEXX/Documents/XXFOLDERNAMEXX")
#NOTE: Adjust the file structure so it correctly refers to the location of the folder containing the input files

## Load in all the input files:

# Planning unit (PU) raster
PU_1km_R = rast("PUID_1km.tif")

# Cost data
cost_1km_tvis_S <- rast("cost_1km_tvis_scaled_S.tif")

# ASPA layer (to be a constraint)
ASPA_1km_R = rast("ASPA_1km.tif")

# Targets
Tar_LB_tvis_baseline = as.matrix(read.csv("Targets/Adjusted/Tar_LB_tvis_baseline.csv", row.names = 1, header=TRUE))
Tar_UB_tvis_baseline = as.matrix(read.csv("Targets/Adjusted/Tar_UB_tvis_baseline.csv", row.names = 1, header=TRUE))
Tar_BG_tvis_baseline = as.matrix(read.csv("Targets/Adjusted/Tar_BG_tvis_baseline.csv", row.names = 1, header=TRUE))
Tar_BG_tvis_modgrowth <- as.matrix(read.csv("Targets/Adjusted/Tar_BG_tvis_modgrowth.csv", row.names = 1, header=TRUE))
Tar_BG_tvis_subgrowth <- as.matrix(read.csv("Targets/Adjusted/Tar_BG_tvis_subgrowth.csv", row.names = 1, header=TRUE))
#NOTE: These targets have already been adjusted as per the methods in the manuscript.
# The original unadjusted target files (defined by the experts, cleaned to ensure targets don't sum to greater than 100%)
# are in the 'Unadjusted' target folder. 

# The tvis raster (containing maximum visitor numbers (from seasons 2015-2020) per planning unit)
max_tvis_1km_R = rast("max_tvis_1km.tif")

# Feature data
# First list all the files that have to be included in the raster stack:
feat_prim_1km_list = list.files(path="Primary_data", pattern = ".tif$", full.names = TRUE)
# Now stack all of those raster files containing the feature data into a stack:
feat_prim_1km_S = rast(feat_prim_1km_list)

## Add the tvis layer to the feature raster stack
feat_prim_1km_tvis_S <- c(feat_prim_1km_S, max_tvis_1km_R)

## Mask the feature layers to ensure all cells that do not contain ice-free area are masked out and not included
feat_prim_1km_tvis_S <- mask(feat_prim_tvis_1km_S, mask = PU_1km_R)

## Create the zone objects required for the prioritisation
# First create a list of the feature names required (else names default to 1,2,3 etc)
prim_1km_fnames = names(feat_prim_tvis_1km_S)
# Create the zone object
prim_1km_tvis_zones = zones(feat_prim_tvis_1km_S, feat_prim_tvis_1km_S, feat_prim_tvis_1km_S, zone_names = c("bio", "sci", "tour"),
                       feature_names = prim_1km_fnames)

## Create the constraint layers
# Create 0 rasters for the sci/tour zones as they have no constraints (for now)
Blank_R1 = ASPA_1km_R
Blank_R1[Blank_R1==1]=0
Blank_R2 = Blank_R1
# Stack the constraints layers into a stack
constr_S = c(ASPA_1km_R, Blank_R1, Blank_R2)

## Create a matrix to define the importance of clumping for different zones
blm_vals = c(1,0,0,0,0,0,0,0,0)
blm_M = matrix(blm_vals, ncol=3, byrow=TRUE)


## Set the conservation problem to be solved by Prioritizr
cons_prob_tvis = problem(cost_1km_tvis_S, prim_1km_tvis_zones)
#NOTE setting problem takes around ~1min


# Remove the now unnecessary files that were used to load the input data
rm(feat_prim_1km_list, prim_1km_fnames, max_tvis_1km_R, feat_prim_1km_S, ASPA_1km_R, Blank_R1, Blank_R2, blm_vals)



###########################################################################################
### STEP 3 - Running the scenarios

## These scenarios use only the best guess targets. The lower and upper bound targets can be subbed in as required.


##############################################################
### Baseline scenario (tvis) - using best guess targets 

## Add objective, targets, type of solver to the conservation problem
cons_prob_tvis_baseline = cons_prob_tvis %>%
  #type of objective
  add_min_set_objective() %>% 
  # set targets
  add_relative_targets(Tar_BG_tvis_baseline) %>%
  # define it as binary
  add_binary_decisions() %>%
  add_gurobi_solver(gap = 0.01) %>% ## This line can be removed if not using the Gurobi solver
  # add constraints
  add_locked_in_constraints(constr_S) %>%
  # add boundary penalties
  add_boundary_penalties(penalty = 100, edge_factor=c(0.5,0,0), zones = blm_M)

## Solve the problem
cons_prob_tvis_baseline_sol = solve(cons_prob_tvis_baseline)

# Plot the solution in R
plot(cons_prob_tvis_baseline_sol)

# calculate the cost of the solution
global(cost_1km_tvis_S * cons_prob_tvis_baseline_sol, fun="sum", na.rm=TRUE) 
# calculate the number of selected planning units
global(cons_prob_tvis_baseline_sol, "sum", na.rm=TRUE)

# Save table containing the target representation
cons_prob_tvis_baseline_sol_tab = eval_feature_representation_summary(cons_prob_tvis_baseline, cons_prob_tvis_baseline_sol)
print(cons_prob_tvis_baseline_sol_tab)
write.csv(cons_prob_tvis_baseline_sol_tab, file = "cons_prob_tvis_baseline_sol_tab.csv", na = "NA")

## Export raster so results can be viewed in GIS
writeRaster(cons_prob_tvis_baseline_sol,  filename ="cons_prob_tvis_baseline_sol_Rast.tif", 
            datatype="FLT4S", overwrite=TRUE)

rm(cons_prob_tvis_baseline_sol, cons_prob_tvis_baseline_sol_tab)


##############################################################
### Moderate Growth scenario (tvis) - using best guess targets 

## Add objective, targets, type of solver to the conservation problem
cons_prob_tvis_modgrowth = cons_prob_tvis %>%
  #type of objective
  add_min_set_objective() %>% 
  # set targets
  add_relative_targets(Tar_BG_tvis_modgrowth) %>%
  # define it as binary
  add_binary_decisions() %>%
  add_gurobi_solver(gap = 0.01) %>% ## This line can be removed if not using the Gurobi solver
  # add constraints
  add_locked_in_constraints(constr_S) %>%
  # add boundary penalties
  add_boundary_penalties(penalty = 100, edge_factor=c(0.5,0,0), zones = blm_M)

## Solve the problem
cons_prob_tvis_modgrowth_sol = solve(cons_prob_tvis_modgrowth)

# Plot the solution in R
plot(cons_prob_tvis_modgrowth_sol)

# calculate the cost of the solution
global(cost_1km_tvis_S * cons_prob_tvis_modgrowth_sol, fun="sum", na.rm=TRUE) 
# calculate the number of selected planning units
global(cons_prob_tvis_modgrowth_sol, "sum", na.rm=TRUE)

# Save table containing the target representation
cons_prob_tvis_modgrowth_sol_tab = eval_feature_representation_summary(cons_prob_tvis_modgrowth, cons_prob_tvis_modgrowth_sol)
print(cons_prob_tvis_modgrowth_sol_tab)
write.csv(cons_prob_tvis_modgrowth_sol_tab, file = "cons_prob_tvis_modgrowth_sol_tab.csv", na = "NA")

## Export raster so results can be viewed in GIS
writeRaster(cons_prob_tvis_modgrowth_sol,  filename ="cons_prob_tvis_modgrowth_sol_Rast.tif", 
            datatype="FLT4S", overwrite=TRUE)

rm(cons_prob_tvis_modgrowth_sol, cons_prob_tvis_modgrowth_sol_tab)


##############################################################
### Substantial Growth scenario (tvis) - using best guess targets 

## Add objective, targets, type of solver to the conservation problem
cons_prob_tvis_subgrowth = cons_prob_tvis %>%
  #type of objective
  add_min_set_objective() %>% 
  # set targets
  add_relative_targets(Tar_BG_tvis_subgrowth) %>%
  # define it as binary
  add_binary_decisions() %>%
  add_gurobi_solver(gap = 0.01) %>% ## This line can be removed if not using the Gurobi solver
  # add constraints
  add_locked_in_constraints(constr_S) %>%
  # add boundary penalties
  add_boundary_penalties(penalty = 100, edge_factor=c(0.5,0,0), zones = blm_M)

## Solve the problem
cons_prob_tvis_subgrowth_sol = solve(cons_prob_tvis_subgrowth)

# Plot the solution in R
plot(cons_prob_tvis_subgrowth_sol)

# calculate the cost of the solution
global(cost_1km_tvis_S * cons_prob_tvis_subgrowth_sol, fun="sum", na.rm=TRUE) 
# calculate the number of selected planning units
global(cons_prob_tvis_subgrowth_sol, "sum", na.rm=TRUE)

# Save table containing the target representation
cons_prob_tvis_subgrowth_sol_tab = eval_feature_representation_summary(cons_prob_tvis_subgrowth, cons_prob_tvis_subgrowth_sol)
print(cons_prob_tvis_subgrowth_sol_tab)
write.csv(cons_prob_tvis_subgrowth_sol_tab, file = "cons_prob_tvis_subgrowth_sol_tab.csv", na = "NA")

## Export raster so results can be viewed in GIS
writeRaster(cons_prob_tvis_subgrowth_sol,  filename ="cons_prob_tvis_subgrowth_sol_Rast.tif", 
            datatype="FLT4S", overwrite=TRUE)

rm(cons_prob_tvis_subgrowth_sol, cons_prob_tvis_subgrowth_sol_tab)

